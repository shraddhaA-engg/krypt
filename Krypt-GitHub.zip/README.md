# Krypt — Startup Showdown

GitHub Pages-ready static demo. Upload `index.html` at the repository root, then enable Pages from `main` / root in Settings → Pages.

This is a browser-only prototype. Demo votes, wallets, staking, rewards, and ETH/USD amounts are simulated; no backend or Ethereum contract is connected.
